<?php
/**
 * Parser SaaS - Конфигурация
 */

// Режим разработки
define('DEBUG', true);

// Домен сайта
define('SITE_URL', 'https://arendadom24.ru');
define('API_URL', SITE_URL . '/api');

// База данных MySQL (Beget)
define('DB_HOST', 'localhost');
define('DB_NAME', 'alexprz7_2026');
define('DB_USER', 'alexprz7_2026');
define('DB_PASS', 'Vitaha2026');

// Apify
define('APIFY_TOKEN', 'apify_api_1IOtsmwqG2lKCs4EfeCmlekRspfxJI3wRgRR');
define('APIFY_AVITO_ACTOR', 'D81KRIfXBnQ4hg8Bz');
define('APIFY_CIAN_ACTOR', 'CBn1BidHkyYcqYpPd');

// Google OAuth
define('GOOGLE_CLIENT_ID', '953394356454-kabeoet6k9edhuicao237669gchd6mvf.apps.googleusercontent.com');
define('GOOGLE_CLIENT_SECRET', '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');
define('GOOGLE_REDIRECT_URI', SITE_URL . '/api/auth/google/callback');

// Telegram Login
define('TELEGRAM_BOT_USERNAME', 'ParsersaasBot');
define('TELEGRAM_BOT_TOKEN', '7906817029:AAHlqi5MKQ0pNlAcTPLpUP0np_xfC3zWxSM');

// JWT секрет для токенов
define('JWT_SECRET', 'pSaAs2024xK9mLqR7vNbZcYwJhFgDsTuAeOiPl3n8');
define('JWT_EXPIRY', 86400 * 30);

// Email (SMTP)
define('SMTP_HOST', 'smtp.beget.com');
define('SMTP_PORT', 465);
define('SMTP_USER', 'noreply@arendadom24.ru');
define('SMTP_PASS', 'Vitaha2026');
define('SMTP_FROM', 'noreply@arendadom24.ru');
define('SMTP_FROM_NAME', 'Parser SaaS');

// Лимиты по умолчанию
define('DEFAULT_DAILY_LIMIT', 100);

// Тарифы
$PLANS = [
    'free' => [
        'name' => 'Free',
        'price_monthly' => 0,
        'price_yearly' => 0,
        'daily_limit' => 100,
        'cities_limit' => 1,
        'features' => ['excel', 'telegram']
    ],
    'basic' => [
        'name' => 'Basic',
        'price_monthly' => 790,
        'price_yearly' => 7500,
        'daily_limit' => 1000,
        'cities_limit' => 5,
        'features' => ['excel', 'telegram', 'google_sheets', 'schedule', 'email_support']
    ],
    'pro' => [
        'name' => 'Pro',
        'price_monthly' => 1990,
        'price_yearly' => 19000,
        'daily_limit' => 10000,
        'cities_limit' => 999,
        'features' => ['excel', 'telegram', 'google_sheets', 'schedule', 'api', 'priority_support']
    ]
];

// Часовой пояс
date_default_timezone_set('Europe/Moscow');

// Обработка ошибок
if (DEBUG) {
    error_reporting(E_ALL);
    ini_set('display_errors', 1);
} else {
    error_reporting(0);
    ini_set('display_errors', 0);
}

// Автозагрузка классов
spl_autoload_register(function ($class) {
    $file = __DIR__ . '/classes/' . $class . '.php';
    if (file_exists($file)) {
        require_once $file;
    }
});
